# LumiVault — Calculator & Private Vault

LumiVault is an independent, clean-room Android application: a fully working calculator
on the surface, and a PIN/biometric-protected private vault underneath.

> This project was built as an original implementation inspired only by the
> *declared manifest and resource names* of a reference package. It contains no code,
> assets, branding, signing keys, or ad SDKs from any third-party application.

## Features

- **Real calculator** — `+`, `−`, `×`, `÷`, `%`, decimals, clear/delete, expression parsing
- **Secret PIN** — set a 4-digit code; typing it in the calculator and pressing `=`
  opens the vault. The PIN is never stored — only a PBKDF2-HmacSHA256
  (120,000 iterations) verifier with a random salt.
- **Biometric unlock** — BiometricPrompt with PIN fallback
- **Encrypted photo vault** — import via Android Photo Picker (no media permission
  needed), stored AES/GCM encrypted in private app storage
- **Encrypted video vault** — thumbnails + Media3 playback
- **Private file manager** — Photos / Videos / Audio / Documents / Other categories
- **Encrypted notes** — AES-GCM encrypted bodies in Room
- **Recycle bin** — soft delete, restore, permanent delete with confirmations
- **Privacy browser** — WebView with back/forward/refresh/home; nothing stored
- **Intruder detection (opt-in)** — after repeated wrong PINs, records a security
  event and (with CAMERA permission granted) a front-camera selfie
- **App lock (best effort)** — AccessibilityService-based, with clear limitations
- **Themes** — System / Light / Dark, Material You dynamic color on Android 12+
- **Auto-lock** — vault locks when the app leaves the foreground

## Tech stack

- Kotlin, Jetpack Compose, Material 3, Navigation Compose
- Room + DataStore
- Android Keystore (AES/GCM) for file encryption
- PBKDF2 for the PIN verifier
- BiometricPrompt, Photo Picker, SAF/OpenDocument, FileProvider
- Media3 ExoPlayer, CameraX, Coil

## Project structure

```
app/src/main/java/com/lumivault/calculator/
├── MainActivity.kt
├── LumiVaultApp.kt
├── security/     CryptoManager, PinHasher, SessionManager, BiometricHelper, IntruderCapture
├── data/
│   ├── db/       Room entities, DAOs, database
│   └── repo/     VaultRepository, NotesRepository, SecurityRepository, SettingsRepository
├── service/      VaultAccessibilityService
└── ui/           theme, navigation, calculator, pin, vault, photos, videos,
                  files, notes, browser, recyclebin, intruder, applock, settings
```

## Build

1. Install Android Studio (latest stable) with SDK 35.
2. Open the project. Android Studio will sync Gradle and generate the wrapper.
   (The `gradle-wrapper.jar` is intentionally not committed; run
   `gradle wrapper` if you build from CLI.)
3. Run `./gradlew assembleDebug` or press **Run ▶**.

Release:

```bash
./gradlew assembleRelease
./gradlew bundleRelease
```

Sign with your own keystore before publishing — never commit `.jks` files.

## Permissions

| Permission | Why | Required |
|---|---|---|
| `USE_BIOMETRIC` | Fingerprint/face unlock | No |
| `INTERNET` | Privacy browser WebView | No |
| `POST_NOTIFICATIONS` | Optional status notification | No |
| `CAMERA` | Intruder selfie (opt-in) | No |
| `READ_MEDIA_IMAGES/VIDEO/AUDIO` | Legacy gallery import fallback | No |

Media import uses the Android Photo Picker, so media permissions can be denied
and importing still works.

## Privacy

- No account, no analytics, no ads, no network calls except the in-app browser.
- All vault content is encrypted with a Keystore-backed AES-256-GCM key.
- The PIN is verified against a salted PBKDF2 hash; the PIN itself is never saved.
- Previews are decrypted only to the app cache and cleared on auto-lock.

See [PRIVACY_POLICY.md](PRIVACY_POLICY.md).

## App lock — honest limitations

Modern Android does not allow one app to reliably "lock" other apps. This project
uses an Accessibility Service to detect foreground apps and re-show the vault lock.
It cannot survive app uninstall, safe mode, force-stop, or the user disabling the
service. Do not market it as unbreakable protection.

## Google Play checklist

- [ ] Replace `applicationId` with your own unique ID
- [ ] Replace app name/icon/branding
- [ ] Fill in the Data Safety form (no data collection; optional camera photo)
- [ ] Host the privacy policy URL
- [ ] Sign with your own upload key; enable Play App Signing
- [ ] Test on Android 8.0 (API 26) through Android 15 (API 35)
- [ ] Verify Accessibility Service disclosure for the app-lock feature

## License

MIT — see [LICENSE](LICENSE). Replace the copyright line with your own name/company.

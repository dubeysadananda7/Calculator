@echo off
REM Placeholder gradlew.bat - open in Android Studio or run `gradle wrapper` once
REM to generate gradle-wrapper.jar
if exist "%~dp0gradle\wrapper\gradle-wrapper.jar" (
  java -jar "%~dp0gradle\wrapper\gradle-wrapper.jar" %*
) else (
  echo gradle-wrapper.jar not found. Open in Android Studio or run: gradle wrapper
  exit /b 1
)

package com.lumivault.calculator.ui.calculator

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.repo.VaultSettings
import com.lumivault.calculator.security.SessionManager
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class CalculatorViewModel(app: Application) : AndroidViewModel(app) {

    private val settings = (app as LumiVaultApp).settings
    private val security = (app as LumiVaultApp).security

    var expression by mutableStateOf("")
        private set
    var result by mutableStateOf("")
        private set
    var error by mutableStateOf<String?>(null)
        private set

    private val _unlockEvent = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val unlockEvent: SharedFlow<Unit> = _unlockEvent

    var settingsSnapshot by mutableStateOf<VaultSettings?>(null)
        private set

    init {
        viewModelScope.launch { settingsSnapshot = settings.settings.first() }
    }

    fun onDigit(d: String) {
        error = null
        val last = expression.lastOrNull()
        if (expression == "0" && d != ".") expression = d
        else if (last?.isDigit() != true && last != '.' && d == "." && last != null) {
            expression += "0."
        } else if (!(last == '.' && d == ".")) {
            expression += d
        }
    }

    fun onOperator(op: String) {
        error = null
        if (expression.isEmpty()) {
            if (op == "-") expression = "-"
            return
        }
        val last = expression.last()
        if (last in "+-x/(") {
            expression = expression.dropLast(1) + op
        } else if (last != '.') {
            expression += op
        }
    }

    fun onPercent() {
        if (expression.isNotEmpty() && expression.last().isDigit()) expression += "%"
    }

    fun onClear() {
        expression = ""
        result = ""
        error = null
    }

    fun onDelete() {
        if (expression.isNotEmpty()) expression = expression.dropLast(1)
    }

    fun onEquals() {
        if (expression.isBlank()) return
        try {
            val value = CalculatorEngine.evaluate(expression)
            result = value
            checkSecretCode(expression.trim())
            expression = value
        } catch (t: Throwable) {
            error = t.message ?: "Error"
        }
    }

    /** The vault opens when the entered expression exactly matches the secret PIN. */
    private fun checkSecretCode(candidate: String) {
        val s = settingsSnapshot ?: return
        if (!s.pinSet) return
        viewModelScope.launch {
            if (settings.verifyPin(candidate, s)) {
                SessionManager.unlock()
                security.recordUnlock()
                _unlockEvent.emit(Unit)
            } else if (candidate.length >= 4 && candidate.all { it.isDigit() }) {
                security.recordPinFail()
            }
        }
    }
}

package com.lumivault.calculator.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultItemDao {
    @Query("SELECT * FROM vault_items WHERE deleted = 0 ORDER BY createdAt DESC")
    fun observeActive(): Flow<List<VaultItemEntity>>

    @Query("SELECT * FROM vault_items WHERE deleted = 1 ORDER BY deletedAt DESC")
    fun observeDeleted(): Flow<List<VaultItemEntity>>

    @Query("SELECT * FROM vault_items WHERE deleted = 0 AND type = :type ORDER BY createdAt DESC")
    fun observeByType(type: String): Flow<List<VaultItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: VaultItemEntity)

    @Query("UPDATE vault_items SET deleted = 1, deletedAt = :now WHERE id = :id")
    suspend fun softDelete(id: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE vault_items SET deleted = 0, deletedAt = NULL WHERE id = :id")
    suspend fun restore(id: String)

    @Query("DELETE FROM vault_items WHERE id = :id")
    suspend fun deletePermanently(id: String)

    @Query("SELECT * FROM vault_items WHERE id = :id")
    suspend fun byId(id: String): VaultItemEntity?
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: NoteEntity)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun delete(id: String)

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun byId(id: String): NoteEntity?
}

@Dao
interface SecurityEventDao {
    @Query("SELECT * FROM security_events ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<SecurityEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: SecurityEventEntity)

    @Query("DELETE FROM security_events WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM security_events")
    suspend fun clear()
}

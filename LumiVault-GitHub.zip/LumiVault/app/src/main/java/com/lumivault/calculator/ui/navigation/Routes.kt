package com.lumivault.calculator.ui.navigation

object Routes {
    const val CALCULATOR = "calculator"
    const val PIN_SETUP = "pin_setup"
    const val PIN_CHANGE = "pin_change"
    const val VAULT = "vault"
    const val PHOTOS = "photos"
    const val PHOTO_VIEWER = "photo_viewer/{id}"
    const val VIDEOS = "videos"
    const val VIDEO_PLAYER = "video_player/{id}"
    const val FILES = "files"
    const val NOTES = "notes"
    const val NOTE_EDIT = "note_edit/{id}"
    const val BROWSER = "browser"
    const val RECYCLE_BIN = "recycle_bin"
    const val INTRUDER = "intruder"
    const val APP_LOCK = "app_lock"
    const val SETTINGS = "settings"

    fun photoViewer(id: String) = "photo_viewer/$id"
    fun videoPlayer(id: String) = "video_player/$id"
    fun noteEdit(id: String?) = "note_edit/${id ?: "new"}"
}

package com.lumivault.calculator.ui.intruder

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.db.SecurityEventEntity
import com.lumivault.calculator.ui.components.EmptyState
import com.lumivault.calculator.ui.components.VaultTopBar
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class IntruderViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as LumiVaultApp).security
    val events = repo.events.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun clear() = viewModelScope.launch { repo.clear() }
    fun format(ts: Long) = repo.formatTime(ts)
}

@Composable
fun IntruderScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm = remember(app) { IntruderViewModel(app) }
    val events by vm.events.collectAsStateWithLifecycle()

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize()) {
            VaultTopBar(
                title = "Security events",
                onBack = { nav.popBackStack() },
                actions = {
                    if (events.isNotEmpty()) {
                        TextButton(onClick = { vm.clear() }) { Text("Clear") }
                    }
                },
            )
            if (events.isEmpty()) {
                EmptyState(
                    Icons.Default.Fingerprint,
                    "No security events",
                    "Failed unlock attempts and intruder selfies will appear here",
                )
            } else {
                LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp)) {
                    items(events, key = { it.id }) { event ->
                        EventRow(event = event, format = vm::format)
                    }
                }
            }
        }
    }
}

@Composable
private fun EventRow(event: SecurityEventEntity, format: (Long) -> String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(event.message, style = MaterialTheme.typography.bodyLarge)
                Text(
                    "${event.kind.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }} · ${format(event.timestamp)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        event.photoPath?.let { path ->
            val file = java.io.File(path)
            if (file.exists()) {
                AsyncImage(
                    model = file,
                    contentDescription = "Intruder photo",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    contentScale = ContentScale.Crop,
                )
            }
        }
    }
}

package com.lumivault.calculator.ui.videos

import android.app.Application
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.db.VaultItemEntity
import com.lumivault.calculator.data.db.VaultItemType
import com.lumivault.calculator.ui.components.ConfirmDialog
import com.lumivault.calculator.ui.components.EmptyState
import com.lumivault.calculator.ui.components.VaultTopBar
import com.lumivault.calculator.ui.navigation.Routes
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class VideosViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as LumiVaultApp).vault

    val videos: StateFlow<List<VaultItemEntity>> = repo.videos()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun import(uris: List<Uri>, onError: (String) -> Unit) {
        viewModelScope.launch {
            uris.forEach { uri ->
                repo.import(uri, VaultItemType.VIDEO).onFailure { onError(it.message ?: "Import failed") }
            }
        }
    }

    suspend fun thumbnail(item: VaultItemEntity): Bitmap? = withContext(Dispatchers.IO) {
        val decrypted = repo.decryptedFile(item)
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(decrypted.absolutePath)
            retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (t: Throwable) {
            null
        } finally {
            runCatching { retriever.release() }
            decrypted.delete()
        }
    }

    suspend fun playableFile(item: VaultItemEntity): File = repo.decryptedFile(item)

    fun delete(item: VaultItemEntity) = viewModelScope.launch { repo.softDelete(item.id) }
}

@Composable
fun VideosScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm = remember(app) { VideosViewModel(app) }
    val videos by vm.videos.collectAsStateWithLifecycle()
    var error by remember { mutableStateOf<String?>(null) }

    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.PickMultipleVisualMedia(maxItems = 10)
    ) { uris -> if (uris.isNotEmpty()) vm.import(uris) { error = it } }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize()) {
            VaultTopBar(title = "Videos", onBack = { nav.popBackStack() })
            if (videos.isEmpty()) {
                EmptyState(Icons.Default.Movie, "No private videos", "Tap + to import videos")
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(videos, key = { it.id }) { item ->
                        VideoCell(item = item, vm = vm) {
                            nav.navigate(Routes.videoPlayer(item.id))
                        }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = {
                picker.launch(
                    androidx.activity.result.PickVisualMediaRequest(
                        androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.VideoOnly
                    )
                )
            },
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            containerColor = MaterialTheme.colorScheme.primary,
        ) {
            Icon(Icons.Default.Add, contentDescription = "Import", tint = MaterialTheme.colorScheme.onPrimary)
        }
        error?.let {
            Text(
                it,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp),
            )
        }
    }
}

@Composable
private fun VideoCell(item: VaultItemEntity, vm: VideosViewModel, onClick: () -> Unit) {
    var confirmDelete by remember { mutableStateOf(false) }
    val thumb by produceState<Bitmap?>(initialValue = null, item.id) { value = vm.thumbnail(item) }

    Box(
        modifier = Modifier
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
    ) {
        thumb?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = item.displayName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        }
        Icon(
            Icons.Default.PlayCircleOutline,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.align(Alignment.Center),
        )
        Text(
            item.displayName,
            color = Color.White,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.align(Alignment.BottomStart).padding(10.dp),
        )
        Text(
            "Delete",
            color = Color(0xFFFF8A80),
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.Black.copy(alpha = 0.4f))
                .clickable { confirmDelete = true }
                .padding(horizontal = 8.dp, vertical = 4.dp),
        )
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = "Move to recycle bin?",
            text = "\"${item.displayName}\" will be moved to the recycle bin.",
            confirmLabel = "Move",
            onConfirm = { vm.delete(item); confirmDelete = false },
            onDismiss = { confirmDelete = false },
        )
    }
}

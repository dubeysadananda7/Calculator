package com.lumivault.calculator.ui.videos

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.ui.components.VaultTopBar
import java.io.File

@Composable
fun VideoPlayerScreen(app: LumiVaultApp, itemId: String, nav: NavHostController) {
    val repo = app.vault
    val context = LocalContext.current

    val item by produceState<com.lumivault.calculator.data.db.VaultItemEntity?>(initialValue = null, itemId) {
        value = repo.byId(itemId)
    }
    val file by produceState<File?>(initialValue = null, item?.id) {
        val current = item ?: return@produceState
        value = repo.playableFileForPlayback(current)
    }

    val player = remember(file) {
        file?.let {
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(Uri.fromFile(it)))
                prepare()
                playWhenReady = true
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            player?.release()
            file?.delete()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
            modifier = Modifier.fillMaxSize(),
        )
        if (file == null) CircularProgressIndicator(Modifier.align(Alignment.Center))
        Box(Modifier.align(Alignment.TopStart)) {
            VaultTopBar(title = item?.displayName ?: "Video", onBack = { nav.popBackStack() })
        }
    }
}

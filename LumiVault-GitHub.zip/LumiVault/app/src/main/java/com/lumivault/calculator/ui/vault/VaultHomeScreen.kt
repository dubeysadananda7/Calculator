package com.lumivault.calculator.ui.vault

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.security.SessionManager
import com.lumivault.calculator.ui.navigation.Routes

private data class VaultModule(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val tint: Color,
    val route: String,
)

private val HomeGradient = Brush.verticalGradient(listOf(Color(0xFF1B1740), Color(0xFF0E0C22)))

@Composable
fun VaultHomeScreen(app: LumiVaultApp, nav: NavHostController) {
    val modules = listOf(
        VaultModule("Photos", "Private photos", Icons.Default.BrokenImage, Color(0xFF8B7CFF), Routes.PHOTOS),
        VaultModule("Videos", "Private videos", Icons.Default.Movie, Color(0xFFFF8A80), Routes.VIDEOS),
        VaultModule("Files", "All file types", Icons.Default.Folder, Color(0xFF64D8CB), Routes.FILES),
        VaultModule("Notes", "Encrypted notes", Icons.Default.Notes, Color(0xFFFFD54F), Routes.NOTES),
        VaultModule("Browser", "Private browsing", Icons.Default.Public, Color(0xFF90CAF9), Routes.BROWSER),
        VaultModule("Recycle bin", "Deleted items", Icons.Default.DeleteOutline, Color(0xFFB0BEC5), Routes.RECYCLE_BIN),
        VaultModule("App lock", "Protect apps", Icons.Default.Lock, Color(0xFFA5D6A7), Routes.APP_LOCK),
        VaultModule("Intruder", "Security log", Icons.Default.Fingerprint, Color(0xFFCE93D8), Routes.INTRUDER),
        VaultModule("Settings", "Security & themes", Icons.Default.Settings, Color(0xFF8B7CFF), Routes.SETTINGS),
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HomeGradient)
            .padding(horizontal = 20.dp, vertical = 28.dp),
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "LumiVault",
                        color = Color.White,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        "Your private space",
                        color = Color(0xFFB9B4E0),
                        fontSize = 14.sp,
                    )
                }
                IconButton(
                    onClick = {
                        SessionManager.lock()
                        nav.navigate(Routes.CALCULATOR) { popUpTo(0) }
                    }
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Lock", tint = Color.White)
                }
            }
            Spacer(Modifier.height(24.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
            ) {
                items(modules) { m ->
                    Card(
                        onClick = { nav.navigate(m.route) },
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF201C48)),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(m.tint.copy(alpha = 0.18f), RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(m.icon, contentDescription = null, tint = m.tint)
                            }
                            Spacer(Modifier.height(14.dp))
                            Text(m.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                            Text(m.subtitle, color = Color(0xFF9C97C9), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

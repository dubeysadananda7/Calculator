package com.lumivault.calculator.ui.files

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.lumivault.calculator.BuildConfig
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.db.VaultItemEntity
import com.lumivault.calculator.data.db.VaultItemType
import com.lumivault.calculator.ui.components.ConfirmDialog
import com.lumivault.calculator.ui.components.EmptyState
import com.lumivault.calculator.ui.components.VaultTopBar
import com.lumivault.calculator.ui.navigation.Routes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val CATEGORIES = listOf("All", "Photos", "Videos", "Audio", "Documents", "Other")

private fun typeOf(mime: String?): VaultItemType = when {
    mime == null -> VaultItemType.OTHER
    mime.startsWith("image/") -> VaultItemType.PHOTO
    mime.startsWith("video/") -> VaultItemType.VIDEO
    mime.startsWith("audio/") -> VaultItemType.AUDIO
    mime == "application/pdf" || mime.contains("text/") ||
        mime.contains("document") || mime.contains("sheet") || mime.contains("presentation") -> VaultItemType.DOCUMENT
    else -> VaultItemType.OTHER
}

private fun iconFor(item: VaultItemEntity): ImageVector = when (item.type) {
    VaultItemType.PHOTO.name -> Icons.Default.BrokenImage
    VaultItemType.VIDEO.name -> Icons.Default.Movie
    VaultItemType.AUDIO.name -> Icons.Default.AudioFile
    VaultItemType.DOCUMENT.name -> Icons.Default.Description
    else -> Icons.Default.InsertDriveFile
}

class FilesViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as LumiVaultApp).vault
    val category = MutableStateFlow("All")

    val items: StateFlow<List<VaultItemEntity>> =
        combine(repo.active(), category) { all, cat ->
            when (cat) {
                "Photos" -> all.filter { it.type == VaultItemType.PHOTO.name }
                "Videos" -> all.filter { it.type == VaultItemType.VIDEO.name }
                "Audio" -> all.filter { it.type == VaultItemType.AUDIO.name }
                "Documents" -> all.filter { it.type == VaultItemType.DOCUMENT.name }
                "Other" -> all.filter { it.type == VaultItemType.OTHER.name }
                else -> all
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun import(uris: List<Uri>, onError: (String) -> Unit) {
        viewModelScope.launch {
            uris.forEach { uri ->
                val mime = getApplication<Application>().contentResolver.getType(uri)
                repo.import(uri, typeOf(mime)).onFailure { onError(it.message ?: "Import failed") }
            }
        }
    }

    fun delete(item: VaultItemEntity) = viewModelScope.launch { repo.softDelete(item.id) }

    fun openExternal(item: VaultItemEntity) = viewModelScope.launch(Dispatchers.IO) {
        val file = repo.decryptedFile(item)
        val context = getApplication<Application>()
        val uri = FileProvider.getUriForFile(context, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, item.mimeType ?: "*/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilesScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm = remember(app) { FilesViewModel(app) }
    val items by vm.items.collectAsStateWithLifecycle()
    val category by vm.category.collectAsStateWithLifecycle()
    var error by remember { mutableStateOf<String?>(null) }

    val importer = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> if (uris.isNotEmpty()) vm.import(uris) { error = it } }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize()) {
            VaultTopBar(title = "Files", onBack = { nav.popBackStack() })
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
            ) {
                CATEGORIES.take(4).forEach { cat ->
                    FilterChip(selected = category == cat, onClick = { vm.category.value = cat }, label = { Text(cat) })
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
            ) {
                CATEGORIES.drop(4).forEach { cat ->
                    FilterChip(selected = category == cat, onClick = { vm.category.value = cat }, label = { Text(cat) })
                }
            }
            if (items.isEmpty()) {
                EmptyState(Icons.Default.Folder, "No files here", "Tap + to import documents, audio, or other files")
            } else {
                LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp)) {
                    items(items, key = { it.id }) { item ->
                        FileRow(item = item, onOpen = {
                            when (item.type) {
                                VaultItemType.PHOTO.name -> nav.navigate(Routes.photoViewer(item.id))
                                VaultItemType.VIDEO.name -> nav.navigate(Routes.videoPlayer(item.id))
                                else -> vm.openExternal(item)
                            }
                        }, onDelete = { vm.delete(item) })
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { importer.launch(arrayOf("*/*")) },
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            containerColor = MaterialTheme.colorScheme.primary,
        ) {
            Icon(Icons.Default.Add, contentDescription = "Import", tint = MaterialTheme.colorScheme.onPrimary)
        }
        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error,
                modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp))
        }
    }
}

@Composable
private fun FileRow(item: VaultItemEntity, onOpen: () -> Unit, onDelete: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable(onClick = onOpen),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(iconFor(item), contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(item.displayName, style = MaterialTheme.typography.bodyLarge)
                Text(
                    "${item.type.lowercase().replaceFirstChar { it.uppercase() }} · ${formatSize(item.sizeBytes)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, contentDescription = null) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; confirmDelete = true })
                }
            }
        }
    }
    if (confirmDelete) {
        ConfirmDialog(
            title = "Move to recycle bin?",
            text = "\"${item.displayName}\" will be moved to the recycle bin.",
            confirmLabel = "Move",
            onConfirm = { onDelete(); confirmDelete = false },
            onDismiss = { confirmDelete = false },
        )
    }
}

internal fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return "%.1f KB".format(kb)
    val mb = kb / 1024.0
    if (mb < 1024) return "%.1f MB".format(mb)
    return "%.2f GB".format(mb / 1024.0)
}

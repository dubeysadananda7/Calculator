package com.lumivault.calculator.data.repo

import com.lumivault.calculator.data.db.NoteDao
import com.lumivault.calculator.data.db.NoteEntity
import com.lumivault.calculator.security.CryptoManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class Note(val id: String, val title: String, val body: String, val createdAt: Long, val updatedAt: Long)

class NotesRepository(private val dao: NoteDao) {

    val notes: Flow<List<Note>> = dao.observeAll().map { list ->
        list.map { n ->
            Note(
                id = n.id,
                title = n.title,
                body = runCatching { CryptoManager.decryptFromBase64(n.bodyEncrypted) }.getOrDefault(""),
                createdAt = n.createdAt,
                updatedAt = n.updatedAt,
            )
        }
    }

    suspend fun save(id: String?, title: String, body: String) {
        val existing = id?.let { dao.byId(it) }
        dao.upsert(
            NoteEntity(
                id = id ?: java.util.UUID.randomUUID().toString(),
                title = title,
                bodyEncrypted = CryptoManager.encryptToBase64(body.toByteArray(Charsets.UTF_8)),
                createdAt = existing?.createdAt ?: System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis(),
            )
        )
    }

    suspend fun delete(id: String) = dao.delete(id)
}

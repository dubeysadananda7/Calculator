package com.lumivault.calculator.ui.calculator

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.ui.components.NumberPad
import com.lumivault.calculator.ui.components.PremiumGradient

private val ScreenGradient = Brush.verticalGradient(
    listOf(Color(0xFF171536), Color(0xFF0E0C22))
)

@Composable
fun CalculatorScreen(app: LumiVaultApp, onUnlock: () -> Unit) {
    val vm: CalculatorViewModel = viewModel(
        factory = remember(app) {
            androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(app)
        }
    )

    LaunchedEffect(Unit) {
        vm.unlockEvent.collect { onUnlock() }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ScreenGradient)
            .padding(horizontal = 20.dp, vertical = 28.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            // Display area
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(top = 48.dp),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Bottom,
            ) {
                Text(
                    vm.expression.ifEmpty { "0" },
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color(0xFFB9B4E0),
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    vm.result.ifEmpty { vm.error ?: "" },
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = if (vm.error != null) MaterialTheme.colorScheme.error
                    else Color.White,
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Spacer(Modifier.height(20.dp))

            // Operators row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                OpButton("C", color = Color(0xFFFF8A80)) { vm.onClear() }
                OpButton("⌫", color = Color(0xFF8B7CFF), icon = Icons.Default.Backspace) { vm.onDelete() }
                OpButton("%", color = Color(0xFF8B7CFF), icon = Icons.Default.Percent) { vm.onPercent() }
                OpButton("÷", color = Color(0xFF64D8CB)) { vm.onOperator("/") }
            }

            Spacer(Modifier.height(14.dp))

            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            NumberPad(
                onKey = { k ->
                    if (k == ".") vm.onDigit(".") else vm.onDigit(k)
                },
                onDelete = { vm.onDelete() },
                onExtra = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        OpButton("−") { vm.onOperator("-") }
                        OpButton("+") { vm.onOperator("+") }
                        OpButton("=") { vm.onEquals() }
                    }
                },
            )
            }
        }
    }
}

@Composable
private fun OpButton(
    label: String,
    color: Color = Color(0xFF8B7CFF),
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        color = if (label == "=") Color(0xFF64D8CB) else Color(0xFF211D45),
        modifier = Modifier.size(width = 84.dp, height = 64.dp),
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (icon != null && label != "=") {
                Icon(icon, contentDescription = label, tint = color)
            } else {
                Text(label, color = if (label == "=") Color(0xFF0E0C22) else color, fontSize = 24.sp)
            }
        }
    }
}

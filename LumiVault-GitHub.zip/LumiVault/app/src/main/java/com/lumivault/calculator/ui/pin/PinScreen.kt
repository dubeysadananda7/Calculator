package com.lumivault.calculator.ui.pin

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.repo.VaultSettings
import com.lumivault.calculator.security.BiometricHelper
import com.lumivault.calculator.security.SessionManager
import com.lumivault.calculator.ui.components.NumberPad
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

enum class PinMode { SETUP, UNLOCK, CHANGE }

class PinViewModel(app: Application) : AndroidViewModel(app) {
    private val settings = (app as LumiVaultApp).settings

    var settingsSnapshot by mutableStateOf<VaultSettings?>(null)
        private set
    var error by mutableStateOf<String?>(null)

    init { viewModelScope.launch { settingsSnapshot = settings.settings.first() } }

    suspend fun verifyCurrent(pin: String): Boolean =
        settingsSnapshot?.let { settings.verifyPin(pin, it) } ?: false

    suspend fun savePin(pin: String) = settings.setPin(pin)
}

private val PinGradient = Brush.verticalGradient(listOf(Color(0xFF171536), Color(0xFF0E0C22)))

@Composable
fun PinScreen(app: LumiVaultApp, mode: PinMode, onDone: () -> Unit) {
    val vm: PinViewModel = viewModel(
        factory = rememberPinFactory(app)
    )
    val activity = LocalContext.current as FragmentActivity

    var pin by androidx.compose.runtime.remember { mutableStateOf("") }
    var stage by androidx.compose.runtime.remember { mutableStateOf(0) } // 0 enter, 1 confirm
    var firstPin by androidx.compose.runtime.remember { mutableStateOf("") }
    val requiredLength = 4 // 4-digit secret code

    fun submit(entered: String) {
        when (mode) {
            PinMode.SETUP -> {
                if (stage == 0) {
                    firstPin = entered; stage = 1; pin = ""
                } else {
                    if (entered == firstPin) {
                        vm.viewModelScopeLaunch { vm.savePin(entered); onDone() }
                    } else {
                        vm.error = "PINs do not match"; stage = 0; pin = ""
                    }
                }
            }
            PinMode.UNLOCK -> {
                vm.viewModelScopeLaunch {
                    if (vm.verifyCurrent(entered)) {
                        SessionManager.unlock()
                        onDone()
                    } else {
                        vm.error = "Wrong secret code"
                        pin = ""
                    }
                }
            }
            PinMode.CHANGE -> {
                if (stage == 0) {
                    vm.viewModelScopeLaunch {
                        if (vm.verifyCurrent(entered)) { stage = 1; pin = "" }
                        else { vm.error = "Wrong current PIN"; pin = "" }
                    }
                } else if (stage == 1) {
                    firstPin = entered; stage = 2; pin = ""
                } else {
                    if (entered == firstPin) {
                        vm.viewModelScopeLaunch { vm.savePin(entered); onDone() }
                    } else {
                        vm.error = "PINs do not match"; stage = 1; pin = ""
                    }
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PinGradient)
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                when (mode) {
                    PinMode.SETUP -> "Create secret code"
                    PinMode.UNLOCK -> "Enter secret code"
                    PinMode.CHANGE -> if (stage == 0) "Enter current PIN" else "Create new PIN"
                },
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                when {
                    vm.error != null -> vm.error!!
                    mode == PinMode.SETUP && stage == 1 -> "Confirm your secret code"
                    mode == PinMode.CHANGE && stage == 2 -> "Confirm new PIN"
                    else -> "Your vault opens only with this code"
                },
                color = if (vm.error != null) MaterialTheme.colorScheme.error else Color(0xFFB9B4E0),
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(28.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                repeat(requiredLength) { i ->
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .background(
                                if (pin.length > i) MaterialTheme.colorScheme.primary
                                else Color.Transparent,
                                CircleShape,
                            )
                            .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape),
                    )
                }
            }
            Spacer(Modifier.height(36.dp))
            NumberPad(
                onKey = { k ->
                    vm.error = null
                    if (k == "." || k == "F") return@NumberPad
                    if (pin.length < requiredLength) pin += k
                    if (pin.length == requiredLength) {
                        val entered = pin
                        pin = ""
                        submit(entered)
                    }
                },
                onDelete = { if (pin.isNotEmpty()) pin = pin.dropLast(1) },
                showFingerprint = mode == PinMode.UNLOCK &&
                    (vm.settingsSnapshot?.biometricEnabled == true),
                onFingerprint = {
                    BiometricHelper.showPrompt(
                        activity = activity,
                        title = "Unlock LumiVault",
                        onSuccess = { SessionManager.unlock(); onDone() },
                        onError = { vm.error = it },
                    )
                },
            )
        }
    }
}

@Composable
private fun rememberPinFactory(app: LumiVaultApp) =
    androidx.compose.runtime.remember(app) {
        androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(app)
    }

private fun PinViewModel.viewModelScopeLaunch(block: suspend () -> Unit) {
    viewModelScope.launch { block() }
}

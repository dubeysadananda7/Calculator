package com.lumivault.calculator.security

import android.content.Context
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import java.io.File
import java.util.concurrent.Executors

/**
 * Best-effort front-camera selfie after repeated failed PIN attempts.
 * Only runs when the user explicitly enabled intruder detection.
 */
object IntruderCapture {

    private const val TAG = "IntruderCapture"

    fun captureSelfie(context: Context, outDir: File, onDone: (File?) -> Unit) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                provider.unbindAll()
                provider.bindToLifecycle(
                    context as androidx.lifecycle.LifecycleOwner,
                    CameraSelector.DEFAULT_FRONT_CAMERA,
                    capture
                )
                val out = File(outDir, "intruder_${System.currentTimeMillis()}.jpg")
                capture.takePicture(
                    ImageCapture.OutputFileOptions.Builder(out).build(),
                    Executors.newSingleThreadExecutor(),
                    object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                            provider.unbindAll()
                            onDone(out)
                        }
                        override fun onError(exception: ImageCaptureException) {
                            Log.w(TAG, "Selfie capture failed", exception)
                            provider.unbindAll()
                            onDone(null)
                        }
                    }
                )
            } catch (t: Throwable) {
                Log.w(TAG, "Selfie capture unavailable", t)
                onDone(null)
            }
        }, ContextCompat.getMainExecutor(context))
    }
}

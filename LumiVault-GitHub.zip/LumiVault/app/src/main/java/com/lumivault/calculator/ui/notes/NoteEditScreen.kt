package com.lumivault.calculator.ui.notes

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.repo.Note
import com.lumivault.calculator.ui.components.ConfirmDialog
import com.lumivault.calculator.ui.components.VaultTopBar
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun NoteEditScreen(app: LumiVaultApp, noteId: String?, nav: NavHostController) {
    val repo = app.notes
    val scope = rememberCoroutineScope()
    val isNew = noteId == null || noteId == "new"

    val all by produceState<List<Note>>(initialValue = emptyList()) {
        value = repo.notes.first()
    }
    val note: Note? = if (isNew) null else all.find { it.id == noteId }

    var title by remember(note?.id) { mutableStateOf(note?.title ?: "") }
    var body by remember(note?.id) { mutableStateOf(note?.body ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }

    fun saveAndExit() {
        scope.launch {
            repo.save(if (isNew) null else noteId, title, body)
            nav.popBackStack()
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        VaultTopBar(
            title = if (isNew) "New note" else "Edit note",
            onBack = { saveAndExit() },
            actions = {
                IconButton(onClick = { saveAndExit() }) {
                    Icon(Icons.Default.Check, contentDescription = "Save")
                }
                if (!isNew) {
                    IconButton(onClick = { confirmDelete = true }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete")
                    }
                }
            },
        )
        Column(Modifier.padding(16.dp)) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = body,
                onValueChange = { body = it },
                label = { Text("Note") },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
            )
            Text(
                "Notes are encrypted with AES-GCM before saving",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = "Delete note?",
            text = "This permanently deletes the note. It cannot be restored.",
            confirmLabel = "Delete",
            onConfirm = {
                scope.launch {
                    noteId?.let { repo.delete(it) }
                    confirmDelete = false
                    nav.popBackStack()
                }
            },
            onDismiss = { confirmDelete = false },
        )
    }
}

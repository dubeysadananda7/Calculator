# LumiVault default ProGuard rules
-dontwarn javax.annotation.**
-keepclassmembers class * { @androidx.room.* *; }

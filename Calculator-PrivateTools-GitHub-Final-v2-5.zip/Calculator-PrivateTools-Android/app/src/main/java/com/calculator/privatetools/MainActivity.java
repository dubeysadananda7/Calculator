package com.calculator.privatetools;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.view.View;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.MobileAds;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.graphics.Color;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONObject;
import java.io.*;
import java.security.KeyStore;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
 private WebView webView; private AdView adView; private LinearLayout root; private static final int PICK_FILE=8102, PICK_IMAGE=8103, PICK_VIDEO=8104;
 private String pendingKind="file"; private static final String KEY_ALIAS="private_tools_aes_v1";
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(17,24,39));getWindow().setNavigationBarColor(Color.rgb(8,11,20));if(Build.VERSION.SDK_INT>=29)getWindow().setNavigationBarContrastEnforced(false);webView=new WebView(this);WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(false);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setMediaPlaybackRequiresUserGesture(true);webView.setBackgroundColor(Color.rgb(8,11,20));webView.addJavascriptInterface(new NativeBridge(),"NativeFiles");webView.setWebViewClient(new WebViewClient());webView.setWebChromeClient(new WebChromeClient());root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(8,11,20));root.addView(webView,new LinearLayout.LayoutParams(-1,0,1f));try{MobileAds.initialize(this,status->{});adView=new AdView(this);adView.setAdSize(AdSize.BANNER);adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");adView.setVisibility(View.GONE);root.addView(adView,new LinearLayout.LayoutParams(-1,-2));setContentView(root);adView.loadAd(new AdRequest.Builder().build());}catch(Exception ignored){setContentView(webView);}webView.loadUrl("file:///android_asset/www/index.html");}
 private SecretKey key() throws Exception {KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(ks.containsAlias(KEY_ALIAS))return (SecretKey)ks.getKey(KEY_ALIAS,null);KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build());return kg.generateKey();}
 private byte[] encrypt(byte[] plain)throws Exception{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());byte[] iv=c.getIV(), enc=c.doFinal(plain);byte[] out=new byte[1+iv.length+enc.length];out[0]=(byte)iv.length;System.arraycopy(iv,0,out,1,iv.length);System.arraycopy(enc,0,out,1+iv.length,enc.length);return out;}
 private byte[] decrypt(byte[] data)throws Exception{int n=data[0]&255;if(n<12||data.length<1+n+16)throw new IOException("Invalid encrypted data");byte[] iv=new byte[n],enc=new byte[data.length-1-n];System.arraycopy(data,1,iv,0,n);System.arraycopy(data,1+n,enc,0,enc.length);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));return c.doFinal(enc);}
 private File storeDir(){File f=new File(getFilesDir(),"encrypted_vault");if(!f.exists())f.mkdirs();return f;}
 private String jsQuote(String s){return JSONObject.quote(s==null?"":s);}
 private void callJs(String method,String json){runOnUiThread(()->webView.evaluateJavascript("window."+method+" && window."+method+"("+json+")",null));}
 private class NativeBridge {
  @JavascriptInterface public void pick(String kind){runOnUiThread(()->{pendingKind=kind==null?"file":kind;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);if("image".equals(pendingKind))i.setType("image/*");else if("video".equals(pendingKind))i.setType("video/*");else i.setType("*/*");startActivityForResult(i,"image".equals(pendingKind)?PICK_IMAGE:"video".equals(pendingKind)?PICK_VIDEO:PICK_FILE);});}
  @JavascriptInterface public String loadSecure(String name){try{File f=new File(getFilesDir(),"secure_"+name+".dat");if(!f.exists())return "";return new String(decrypt(readAll(new FileInputStream(f))),java.nio.charset.StandardCharsets.UTF_8);}catch(Exception e){return "";}}
  @JavascriptInterface public boolean saveSecure(String name,String value){try{if(!name.matches("[a-zA-Z0-9_-]{1,40}"))return false;File f=new File(getFilesDir(),"secure_"+name+".dat");try(FileOutputStream o=new FileOutputStream(f)){o.write(encrypt((value==null?"":value).getBytes(java.nio.charset.StandardCharsets.UTF_8)));}return true;}catch(Exception e){return false;}}
  @JavascriptInterface public void setPrivateVisible(boolean visible){runOnUiThread(()->{if(adView!=null)adView.setVisibility(visible?View.VISIBLE:View.GONE);});}
  @JavascriptInterface public boolean deleteVaultFile(String id){try{if(!id.matches("[a-f0-9]{32}"))return false;return new File(storeDir(),id+".vault").delete();}catch(Exception e){return false;}}
 }
 private static byte[] readAll(InputStream in)throws IOException{try(InputStream input=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[65536];int n;while((n=input.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}}
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();String name="Selected file";try(Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(ix>=0&&c.getString(ix)!=null)name=c.getString(ix);}}catch(Exception ignored){}String mime=getContentResolver().getType(uri);String id=java.util.UUID.randomUUID().toString().replace("-","");try(InputStream in=getContentResolver().openInputStream(uri);FileOutputStream out=new FileOutputStream(new File(storeDir(),id+".vault"))){if(in==null)throw new IOException("Unable to read selected file");Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());byte[] iv=c.getIV();out.write(iv.length);out.write(iv);// Do not write Cipher.update(empty) here; it may return null and crash import.
try(javax.crypto.CipherOutputStream cos=new javax.crypto.CipherOutputStream(out,c)){byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1)cos.write(buf,0,n);}String payload="{"+"\"id\":"+jsQuote(id)+",\"name\":"+jsQuote(name)+",\"mime\":"+jsQuote(mime==null?"application/octet-stream":mime)+",\"kind\":"+jsQuote(pendingKind)+",\"added\":"+jsQuote(java.text.DateFormat.getDateTimeInstance().format(new java.util.Date()))+"}";callJs("onNativeFileEncrypted",payload);}catch(Exception e){new android.app.AlertDialog.Builder(this).setMessage("Could not encrypt this file. Please try a smaller file or another storage provider.").setPositiveButton("OK",null).show();}}
 @Override public void onBackPressed(){if(webView!=null)webView.evaluateJavascript("window.handleAndroidBack && window.handleAndroidBack()",null);else super.onBackPressed();}
}

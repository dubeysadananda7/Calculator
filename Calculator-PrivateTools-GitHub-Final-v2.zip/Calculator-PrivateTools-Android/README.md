# Calculator Private Tools — GitHub Actions Build

This is a prototype Android project for GitHub Actions builds.

## Build configuration
- Android Gradle Plugin: 9.4.0
- Gradle: 9.6.0 (installed by the GitHub workflow)
- Java: 17
- compileSdk / targetSdk: 37
- Android SDK Build Tools: 36.0.0 (supported default for AGP 9.4)

## GitHub Actions build
The separate workflow file `build-apk-fixed.yml` expects the project archive to be uploaded at repository root as `Calculator-PrivateTools-GitHub-Final-v2.zip`. Create the repository workflow file at `.github/workflows/build-apk-fixed.yml` using that workflow's complete contents. Then check Actions for **Build Calculator APK (Fixed)**. A successful build produces the `Calculator-debug-APK` artifact.

## Prototype limitations
This is not a finished production security app. Do not store sensitive personal documents until encryption, decryption/preview/export, recovery behavior, and end-to-end security are fully tested. The current vault file import path encrypts imported files, but encrypted files cannot yet be reopened or exported from the UI. App hiding/system-wide app locking is not provided. AdMob currently uses Google's test app/ad IDs; replace them with your own approved IDs only after testing and release preparation.

# Calculator – Private Tools (GitHub Actions build project)

A Java Android project with an offline HTML interface. The launch screen is a calculator; entering the demo PIN and pressing `=` opens the private dashboard. `compileSdk` and `targetSdk` are configured as 37.

## Current implementation
- Calculator UI and private dashboard.
- Demo PIN `2580`; change it in Settings immediately.
- PIN, notes, and vault index stored in app-private encrypted files using AES-GCM and an Android Keystore key.
- Five wrong PIN attempts trigger a 30-second lockout.
- Selected files are copied into app-private storage and encrypted with AES-GCM; original files are not deleted.
- Google AdMob SDK is integrated with Google's official test application and banner IDs.
- GitHub Actions installs Java 17, Gradle 8.13, Android SDK packages, builds a debug APK, and uploads it as an artifact.

## Important limitations
- **The project has not been compiled or device-tested in this environment.** The first GitHub Actions run is the actual build test. If the Android API 37 SDK/build-tools packages are not yet available on the runner, the workflow will fail at SDK installation and must be adjusted to the currently published SDK packages.
- The ZIP does not include Gradle Wrapper files. The GitHub workflow installs Gradle 8.13 directly, so the workflow does not require `gradlew`. For Android Studio local builds, install Gradle 8.13 and JDK 17 or generate a wrapper from a working Gradle installation.
- The default PIN `2580` is a demo convenience. It is encrypted at rest, but a salted password-hash flow has not been implemented.
- Files are encrypted at rest, but the app does not yet include an in-app decrypt/view/export workflow. Keep the original files separately. Uninstalling the app or losing its Keystore key can make the encrypted vault unrecoverable.
- Notes have encrypted storage, but a Trash/recovery screen is not implemented yet.
- The app does not hide other installed apps or lock other apps system-wide. Android restricts those functions for ordinary apps.
- This is an early prototype, not a security-audited vault. Do not use it as the only copy of sensitive or important data.

## Build APK on GitHub (phone-friendly steps)
1. Open an empty GitHub repository.
2. Extract this ZIP on your phone. In GitHub, choose **Add file → Upload files** and upload the extracted project's contents (not the ZIP itself). Include the `.github` folder; the workflow file must end up at `.github/workflows/build-apk.yml`.
3. Commit the files to the `main` branch.
4. Open **Actions → Build Calculator APK**. If needed, tap **Run workflow**.
5. Open the completed run and download the `Calculator-debug-APK` artifact. If the run is red, open it and share a screenshot of the first error.

## Project structure
- `app/` — Android application source and assets
- `.github/workflows/build-apk.yml` — GitHub Actions APK build workflow
- `build.gradle`, `settings.gradle`, `gradle.properties` — Gradle project configuration
